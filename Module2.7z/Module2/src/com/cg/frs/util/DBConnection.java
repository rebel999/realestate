package com.cg.frs.util;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
public class DBConnection {
public static Connection getConnection() throws SQLException, IOException
{	
	Connection conn=null;
	Properties prop=readdbInfo();
	String url=prop.getProperty("url");				//fetch the url
	String username=prop.getProperty("username");	//fetch the username
	String password=prop.getProperty("password");	//fetch the password
	conn=DriverManager.getConnection(url,username,password);		//establishing the connection to database
	return conn;
}
private static Properties readdbInfo() throws IOException
{
Properties p=new Properties();
FileReader fr= new FileReader("resources\\database.properties"); 			//read the registration.properties file
p.load(fr);			//loading the registration.properties file
return p;			//returning the file
}
}
