package com.cg.frs.util;

import static org.junit.Assert.assertNotNull;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RegistrationException;


public class JunitTest {

	static IFlatRegistrationDAO dao=null;
	static FlatRegistrationDTO bean=null;
	
@BeforeClass
public static void initialize() {
	System.out.println("Hi");
	try {
		dao=new FlatRegistrationDAOImpl();
	} catch (Exception e) {
		e.printStackTrace();
	}
	bean=new FlatRegistrationDTO();
	
}
@Test
public void testData(){
	
	bean.setOwner_Id(1);
	bean.setFlat_type(2);
	bean.setFlat_area(123);
	bean.setRent_amt(6000);
	bean.setDeposit_amt(7000);
}
@Test
public void testAddDetails() throws  RegistrationException{
			assertNotNull(dao.FlatRegistration(bean));
		}
@Test
public void getDetails() throws  RegistrationException, SQLException, IOException{
	assertNotNull(dao.getAllOwnerIds());
}

}
