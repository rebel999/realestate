package com.cg.frs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RegistrationException;
import com.cg.frs.util.DBConnection;


public class FlatRegistrationDAOImpl  implements IFlatRegistrationDAO
{
	Connection conn=null;
	int result=0;
	
	public FlatRegistrationDAOImpl() {
		PropertyConfigurator.configure("resources//Log4j.Properties");
	}
	public int FlatRegistration(FlatRegistrationDTO flat) throws RegistrationException{
		Logger log=Logger.getRootLogger();
		try {
		//establishing the connection using getConnection method 	
		conn=DBConnection.getConnection();
		//query to insert the values to the database table flat_registration
		String insertQuery="insert into flat_registration values(flat_seq.nextval,?,?,?,?,?)";
		PreparedStatement ps=conn.prepareStatement(insertQuery);
		ps.setInt(1, flat.getOwner_Id());
		ps.setInt(2, flat.getFlat_type());
		ps.setInt(3, flat.getFlat_area());
		ps.setInt(4,flat.getRent_amt());
		ps.setInt(5, flat.getDeposit_amt());
		ps.executeUpdate();
		String sql="select flat_seq.CURRVAL from flat_registration";
		Statement ps1=conn.createStatement();
		ResultSet rs=ps1.executeQuery(sql);
		while(rs.next())
		{
			
			result=rs.getInt(1);
		}
		//to add data to the log file
		log.info("database updated successfully");
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return result;
	}
	public ArrayList<Integer> getAllOwnerIds() throws RegistrationException{
		Logger log=Logger.getRootLogger(); 
		ArrayList<Integer> list=new ArrayList<Integer>(); //creating the list to store owner ids
		try {
			//establishing the connection using getConnection method 
			conn=DBConnection.getConnection();
		String selectQuery="select owner_id from flat_owners";
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(selectQuery);
		while(rs.next())
		{
			int oid=rs.getInt(1);
			list.add(new Integer(oid));
		}
		//to add data to the log file
		log.info("data fetched successfully");
		}
		catch (SQLException | IOException e) {
			e.printStackTrace();
		}
		return list;
	}
}

