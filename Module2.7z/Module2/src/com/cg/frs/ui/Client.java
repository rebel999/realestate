package com.cg.frs.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RegistrationException;
import com.cg.frs.service.FlatRegistrationServiceImpl;



public class Client {
	static Scanner sc=new Scanner(System.in);
	static FlatRegistrationDTO flatDetail=null;
	static FlatRegistrationServiceImpl flatService=null;
	public static void main(String[] args) throws RegistrationException {
		System.out.println("Real Estate Registration Service");
		System.out.println("____________________________________");
		while(true)
		{	//menu 
			System.out.println("1. Register Flat");
			System.out.println("2. Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1: registrationDetails();			
					break;
			case 2: System.exit(0);
			default:
				System.out.println("Wrong choice");
			
					
			}

	}
	

}
	private static void registrationDetails() throws RegistrationException {
		getAllOwnerIds(); //to find the owner id 
		flatService=new FlatRegistrationServiceImpl();
		System.out.println("Please enter your owner id from above list:");
		int id=sc.nextInt();
		if(flatService.validateOwnerId(id))
		{
		System.out.println("Select Flat type Type (1-1BHK, 2-2BHK)");
		int type=sc.nextInt();
		if(flatService.validateFlatType(type))
		{
		System.out.println("Enter Flat area in sq. ft.: ");
		int area=sc.nextInt();
		if(flatService.validateFlatArea(area))
		{
		System.out.println("Enter desired rent amount Rs: ");
		int rent=sc.nextInt();
		if(flatService.validateRentAmount(rent))
		{
		System.out.println("Enter desired deposit amount Rs: ");
		int deposit=sc.nextInt();
		if(flatService.validateDepositAmount(deposit))
		{
			if(flatService.validateAmount(rent,deposit))
			{
		flatDetail=new FlatRegistrationDTO(id,type,area,rent,deposit);
		int res=flatService.FlatRegistration(flatDetail);
		System.out.println("Flat successfully registered. FlatRegistration Number:"+"<"+res+">");
			}
		}
	}}}}
}
	private static void getAllOwnerIds() throws RegistrationException {
		ArrayList<Integer> list=null;
		flatService=new FlatRegistrationServiceImpl();
		list=flatService.getAllOwnerIds();
		System.out.println("Existing Flat Owner ID'S:");
		System.out.println(list);
		
	}
}
