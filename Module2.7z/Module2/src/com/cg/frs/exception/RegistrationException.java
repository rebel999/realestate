package com.cg.frs.exception;

public class RegistrationException extends Exception{
	private static final long serialVersionUID = 1L;
	int d;

	public RegistrationException(int data) {
		d=data;
		System.out.println("Database doesn't contain Owner Id "+d);
		System.out.println("<Owner does not exits>");
	}
	public RegistrationException(String string) {
		// TODO Auto-generated constructor stub
	}
	@Override
		public String toString()
		{
			return "HotelException";
		}
}
		

