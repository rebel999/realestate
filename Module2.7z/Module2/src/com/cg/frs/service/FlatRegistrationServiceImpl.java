package com.cg.frs.service;

import java.util.ArrayList;
import java.util.regex.Pattern;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RegistrationException;


public class FlatRegistrationServiceImpl implements IFlatRegistrationService
{
	IFlatRegistrationDAO dao=null;
	public int FlatRegistration(FlatRegistrationDTO flat)throws RegistrationException 
	{
		dao=new FlatRegistrationDAOImpl();
		return dao.FlatRegistration(flat);
	}
	public ArrayList<Integer> getAllOwnerIds() throws RegistrationException 
	{
		IFlatRegistrationDAO d=new FlatRegistrationDAOImpl();
		return d.getAllOwnerIds();
	}
	public boolean validateOwnerId(int id) {
		String s=Integer.toString(id);
		String pattern="[123]{1}";
		if(Pattern.matches(pattern,s))
		{
			return true;
		}
		else
		{
			try {
				throw new RegistrationException(id);
			} catch (RegistrationException e) {
				System.out.println(e);
			}
		}
		return false;
	}

	public boolean validateFlatType(int type) {
		String s=Integer.toString(type);
		String pattern="[12]{1}";
		if(Pattern.matches(pattern,s))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter the valid Flat Type");
			return false;
		}
	}

	public boolean validateFlatArea(int area) {
		String s=Integer.toString(area);
		String pattern="[0-9]{3,4}";
		if(Pattern.matches(pattern,s))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter the valid Flat Area");
			return false;
		}
	}

	public boolean validateRentAmount(int rentAmt) {
		String s=Integer.toString(rentAmt);
		String pattern="[0-9]{4,6}";
		if(Pattern.matches(pattern,s))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter the valid Flat Rent Amount");
			return false;
		}
	}

	public boolean validateDepositAmount(int depositAmt) {
		String s=Integer.toString(depositAmt);
		String pattern="[0-9]{4,6}";
		if(Pattern.matches(pattern,s))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter the valid Flat Deposit Amount");
			return false;
		}
	}
	public boolean validateAmount(int rent, int deposit) {
		if(rent<deposit)
			return true;
		else
		{
			System.out.println("Please enter the valid Deposit Amount. It can't be less than Rent Amount.");
			return false;
	}
	
}
	
}

