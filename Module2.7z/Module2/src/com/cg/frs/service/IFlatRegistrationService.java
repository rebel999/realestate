package com.cg.frs.service;
import java.util.ArrayList;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.RegistrationException;

public interface IFlatRegistrationService{
	public int FlatRegistration(FlatRegistrationDTO flat) throws RegistrationException;
	public ArrayList<Integer> getAllOwnerIds() throws RegistrationException;
	public boolean validateOwnerId(int id);						//abstract method to call the validateOwnerId method in the implementation layer
	public boolean validateFlatType(int type);					//abstract method to call the validateFlatType method in the implementation layer
	public boolean validateFlatArea(int area);					//abstract method to call the validateFlatArea method in the implementation layer
	public boolean validateRentAmount(int rentAmt);				//abstract method to call the validateRentAmt method in the implementation layer
	public boolean validateDepositAmount(int depositAmt);		//abstract method to call the validateDepositAmt method in the implementation layer
	public boolean validateAmount(int rent, int deposit);		//abstract method to call the validateAmount method in the implementation layer
}
