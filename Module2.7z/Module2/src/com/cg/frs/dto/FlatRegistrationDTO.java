package com.cg.frs.dto;

public class FlatRegistrationDTO {
	private int flat_reg_no;
	private int owner_Id;
	private int flat_type;
	private int Flat_area;
	private int rent_amt;
	private int deposit_amt;
	
	public FlatRegistrationDTO() {
		super();
	}
	public FlatRegistrationDTO(int owner_Id, int flat_type, int flat_area,
			int rent_amt, int deposit_amt) {
		super();
		this.owner_Id = owner_Id;
		this.flat_type = flat_type;
		Flat_area = flat_area;
		this.rent_amt = rent_amt;
		this.deposit_amt = deposit_amt;
	}
	public FlatRegistrationDTO(int flat_reg_no, int owner_Id, int flat_type,
			int flat_area, int rent_amt, int deposit_amt) {
		super();
		this.flat_reg_no = flat_reg_no;
		this.owner_Id = owner_Id;
		this.flat_type = flat_type;
		Flat_area = flat_area;
		this.rent_amt = rent_amt;
		this.deposit_amt = deposit_amt;
	}
	public int getFlat_reg_no() {
		return flat_reg_no;
	}
	public void setFlat_reg_no(int flat_reg_no) {
		this.flat_reg_no = flat_reg_no;
	}
	public int getOwner_Id() {
		return owner_Id;
	}
	public void setOwner_Id(int owner_Id) {
		this.owner_Id = owner_Id;
	}
	public int getFlat_type() {
		return flat_type;
	}
	public void setFlat_type(int flat_type) {
		this.flat_type = flat_type;
	}
	public int getFlat_area() {
		return Flat_area;
	}
	public void setFlat_area(int flat_area) {
		Flat_area = flat_area;
	}
	public int getRent_amt() {
		return rent_amt;
	}
	
	public void setRent_amt(int rent_amt) {
		this.rent_amt = rent_amt;
	}
	public int getDeposit_amt() {
		return deposit_amt;
	}
	public void setDeposit_amt(int deposit_amt) {
		this.deposit_amt = deposit_amt;
	}

}
