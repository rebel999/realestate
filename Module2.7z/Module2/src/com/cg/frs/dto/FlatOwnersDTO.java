package com.cg.frs.dto;

public class FlatOwnersDTO {
	//attributes of the flat owner
	private int owner_id;
	private String owner_name;
	private String mobile;
	
	public int getOwner_id() {
		return owner_id;
	}
	public void setOwner_id(int owner_id) {
		this.owner_id = owner_id;
	}
	public String getOwner_name() {
		return owner_name;
	}
	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public FlatOwnersDTO() {
		super();
	}
}
